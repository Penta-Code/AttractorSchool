﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace HomeWork20_2
{
    internal class EmployeeCollection
    {
        public string[] EmployeesList { get; set; }

        public Employee[] Employees { get; set; }

        public void PrintUsers()
        {
            Console.WriteLine("Список сотрудников:\n");
            Console.WriteLine("Номер | ФИО     | Должность  | Год  ");
            Console.WriteLine("------|---------|------------|------");
            foreach (var emp in Employees)
            {
                Console.WriteLine($"{emp.Number}     | {emp.FirstName}  | {emp.LastName}   | {emp.Profession}   | {emp.Year}");
            }
        }

        public void FillUsersObjects(string[] list)
        {
            Employees = new Employee[list.Length];

            for (int i = 0; i < list.Length; i++)
            {
                string[] props = list[i].Split(' ');

                var newEmp = new Employee (props[0], props[1], props[2], props[3], props[4]);

                Employees[i] = newEmp;
            }
        }

        public void Filter(string text)
        {
            int counter = 0;

            Console.WriteLine("\nРезультат:\n");
            Console.WriteLine("Номер | ФИО     | Должность  | Год  ");
            Console.WriteLine("------|---------|------------|------");
            foreach (var emp in Employees)
            {
                if (emp.Profession == text)
                {
                    Console.WriteLine($"{emp.Number}     | {emp.FirstName}  | {emp.LastName}   | {emp.Profession}   | {emp.Year}");
                    counter++;
                }
            }

            for (int i = 0; i < EmployeesList.Length; i++)
            {
                if (EmployeesList[i].Contains(text))
                {
                    File.AppendAllText("../../../out.txt", $"{EmployeesList[i]}\n");
                }
            }
        }
    }
}